package Controler;

/**
 * La classe abstraite Controler dont toutes les classes controleurs
 * hérite.
 * @author Dimitri Calmels & Xavier Fernandez
 *
 */

public abstract class Controler {

}
